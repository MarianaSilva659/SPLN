# TPC 2

### Tarefa

Completar filtro da aula 2 com novas opções

### Resultado

- (Sem argumento) Por default remover as frases repetidas mantendo linhas vazias.
- -s Manter os espaços nas linhas.
- -e Remove empty lines.
- -p Comentar as linhas que foram removidas.

